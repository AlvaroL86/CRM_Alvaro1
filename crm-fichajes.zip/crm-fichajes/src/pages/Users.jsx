// src/pages/Users.jsx
export default function Users() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Gestión de Usuarios</h2>
      <p>Aquí irá la tabla y gestión de usuarios.</p>
    </div>
  );
}
