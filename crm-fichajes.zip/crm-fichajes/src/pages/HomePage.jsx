export default function HomePage() {
  return (
    <div>
      <h2 className="text-3xl font-bold mb-2 text-blue-700">Bienvenido al CRM</h2>
      <p className="text-gray-600">Selecciona una opción del menú para comenzar.</p>
    </div>
  );
}
